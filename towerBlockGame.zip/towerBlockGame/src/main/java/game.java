import model.Coordinates;
import model.Tower;
import ui.mainWindow;

public class game {
    public static void main(String[] args) {
        mainWindow window = new mainWindow();
        javax.swing.SwingUtilities.invokeLater(window);
        window.setTitle("Tower Game");
        window.addTower();
    }
}
