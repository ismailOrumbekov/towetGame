package model;

import java.awt.*;

public interface Mapable {
    Color getBoxColor(int x, int y);
}
