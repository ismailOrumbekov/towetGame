package model;

import java.util.ArrayList;
import java.util.List;

public enum Tower {
    tower(0,1, 1,1, 0,0, 1,0);
    public List<Coordinates> positions;
    public Coordinates top;
    public Coordinates bot;

    Tower(int ... coords){
        positions = new ArrayList<>();
        for(int i = 0; i < coords.length; i+= 2){
            positions.add(new Coordinates(coords[i], coords[i+1]));
        }
        top = setTop();
        bot = setBot();
    }
    private Coordinates setTop(){
        int x = positions.get(0).x;
        int y = positions.get(0).y;

        for (Coordinates coordinates : positions){
            if(x > coordinates.x) x = coordinates.x;
            if(y > coordinates.y) y = coordinates.y;
        }
        return new Coordinates(x, y);
    }
    private Coordinates setBot(){
        int x = positions.get(0).x;
        int y = positions.get(0).y;

        for (Coordinates coordinates : positions){
            if(x < coordinates.x) x = coordinates.x;
            if(y < coordinates.y) y = coordinates.y;
        }
        return new Coordinates(x, y);
    }



}
