package service;

import model.Coordinates;
import model.Mapable;
import model.Tower;
import ui.Configurations;

import java.awt.*;

public class currentTower {
    private Tower tower;
    private Coordinates coordinates;
    Mapable mapable;
    public currentTower(Mapable mapable){
        this.mapable = mapable;
        tower = Tower.tower;
        coordinates = new Coordinates(Configurations.WIDTH / 2 - 1, 4);
    }

    public boolean canMoveTower(int x, int y){
        if(coordinates.x + x + tower.top.x < 0) return false;
        if(coordinates.x + x + tower.bot.x >= Configurations.WIDTH) return false;
        if(coordinates.y + y + tower.top.y < 0) return false;
        if(coordinates.y + y + tower.bot.y >= Configurations.HEIGHT) return false;

        for(Coordinates points : tower.positions){
            if(mapable.getBoxColor(coordinates.x + points.x + x, coordinates.y + points.y + y) == Configurations.fixed){
                return false;
            }
        }
        return true;
    }

    public void moveTower(int x, int y){
        if(canMoveTower(x, y)){
            coordinates = coordinates.plus(x,y);
        }else {
            System.out.println("can not move");
        }
    }

    public Coordinates getCoordinates() {
        return coordinates;
    }

    public Tower getTower() {
        return tower;
    }
}
