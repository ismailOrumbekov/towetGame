package ui;

import java.awt.*;

public class Configurations {
    public static final int WIDTH = 10;
    public static final int HEIGHT = 20;
    public static final int SIZE = 30;

    public static final Color Back = Color.black;
    public static final Color Box = Color.WHITE;
    public static final Color fixed = Color.DARK_GRAY;
}
