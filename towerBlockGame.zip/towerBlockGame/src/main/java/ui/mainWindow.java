package ui;

import model.Coordinates;
import model.Mapable;
import service.currentTower;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class mainWindow extends JFrame implements Runnable, Mapable {
    Box[][] boxes;
    static int counter = 0;
    private int xDirection = 1;
    private int yDirection = 1;
    private currentTower currentTower;
    private Timer timer;
    private TimeAdapter timeAdapter;
    public mainWindow(){
        boxes = new Box[Configurations.WIDTH][Configurations.HEIGHT];
        initForm();
        initBoxes();
        addKeyL();
        timeAdapter = new TimeAdapter();
        timer = new Timer(100, timeAdapter);
        timer.start();
    }

    public void addTower(){
        yDirection = 1;
        currentTower = new currentTower(this );
        System.out.println("w");
        showTower();
    }

    private void initForm(){
        setSize(Configurations.WIDTH * Configurations.SIZE + 15, Configurations.HEIGHT * Configurations.SIZE + 15);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        setVisible(true);
    }

    private void initBoxes(){
        for(int x = 0; x < Configurations.WIDTH; x++){
            for(int y = 0; y < Configurations.HEIGHT; y++){
                boxes[x][y] = new Box(x, y);
                add(boxes[x][y]);
            }
        }
    }

    public Color getBoxColor(int x, int y){
        if(x <0 || x >= Configurations.WIDTH) return Color.BLACK;
        if(y <0 || y >= Configurations.HEIGHT) return Color.BLACK;
        return boxes[x][y].getBackground();
    }

    private void showTower(){
        showTower(Color.white);
    }
    private void hideTower(){
        showTower(Color.black);
    }

    public void showTower(Color color){
        for(Coordinates c : currentTower.getTower().positions){
            setBoxColor(currentTower.getCoordinates().x +c.x,
                    currentTower.getCoordinates().y + c.y, color);
        }
    }

    void setBoxColor(int x, int y, Color color){
        if(x <0 || x >= Configurations.WIDTH) return;
        if(y <0 || y >= Configurations.HEIGHT) return;

            boxes[x][y].setBackground(color);

    }

    @Override
    public void run() {
        repaint();
    }
    void addKeyL(){
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                super.keyPressed(e);
                hideTower();
                if(e.getKeyCode() == KeyEvent.VK_S){
                    currentTower.moveTower(0, 1);
                }else if(e.getKeyCode() == KeyEvent.VK_SPACE){
                    timeAdapter.isFalling = true;

                }
                showTower();
            }
        });
    }

    class TimeAdapter implements ActionListener{
        boolean isFalling;
        @Override
        public void actionPerformed(ActionEvent e) {
            if(!currentTower.canMoveTower(0, 1)){
                showTower(Configurations.fixed);
                    addTower();
                    isFalling = false;
            }
            if (!isFalling){
                hideTower();
                if (currentTower.getCoordinates().x == 4) {
                    System.out.println("pos");
                    yDirection *= -1;
                }
                if (currentTower.canMoveTower(xDirection, yDirection)) {
                    currentTower.moveTower(xDirection, yDirection);
                } else {
                    xDirection *= -1;
                    yDirection *= -1;
                    currentTower.moveTower(xDirection, yDirection);
                }
                showTower();
        }else{
                hideTower();
                currentTower.moveTower(0, 1);
                showTower();
            }
        }
    }
}
