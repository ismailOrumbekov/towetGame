package ui;

import javax.swing.*;
import javax.swing.text.Element;
import javax.swing.text.html.ImageView;
import java.awt.*;

public class Box extends JPanel {
    public Box(int x, int y){
        setBounds(x * Configurations.SIZE, y * Configurations.SIZE, Configurations.SIZE + 15, Configurations.SIZE);
        setBackground(Configurations.Back);
    }
    public Color getColor(){
        return getBackground();
    }



}
